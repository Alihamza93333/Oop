﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace PasswordBruteForce.Models
{
    public static class PasswordEncryptor
    {
        private static readonly string Salt = "staticSalt";

        public static string EncryptPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] saltedPassword = Encoding.UTF8.GetBytes(Salt + password);
                byte[] hash = sha256.ComputeHash(saltedPassword);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
