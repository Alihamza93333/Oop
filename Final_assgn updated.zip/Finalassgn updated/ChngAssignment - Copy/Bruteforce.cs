﻿using System;
using System.Text;
using System.Threading.Tasks;

namespace PasswordBruteForce.Models
{
    public class BruteForce
    {
        private static readonly char[] Characters = "abcdefghijklmnopqrstuvwxyz1234567890".ToCharArray();

        public Task<string> DecryptPasswordAsync(string encryptedPassword, int maxThreads)
        {
            return Task.Run(() => DecryptPassword(encryptedPassword, maxThreads));
        }

        private string DecryptPassword(string encryptedPassword, int maxThreads)
        {
            string result = null;
            ParallelOptions parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = maxThreads };
            Parallel.ForEach(Characters, parallelOptions, (character, state) =>
            {
                if (BruteForceRecursive(character.ToString(), encryptedPassword, ref result))
                {
                    state.Stop();
                }
            });
            return result;
        }

        private bool BruteForceRecursive(string attempt, string encryptedPassword, ref string result)
        {
            if (PasswordEncryptor.EncryptPassword(attempt) == encryptedPassword)
            {
                result = attempt;
                return true;
            }

            if (attempt.Length >= 5) // Limit the password length for demo purposes
                return false;

            foreach (char character in Characters)
            {
                if (BruteForceRecursive(attempt + character, encryptedPassword, ref result))
                    return true;
            }

            return false;
        }
    }
}
